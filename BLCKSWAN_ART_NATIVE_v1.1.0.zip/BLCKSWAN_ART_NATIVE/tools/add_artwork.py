#!/usr/bin/env python3
import argparse, json
from pathlib import Path

parser = argparse.ArgumentParser(description="Legg et verk til BLCKSWAN ART-utstillingen")
parser.add_argument("--file", default="app/src/main/assets/exhibition.json")
args = parser.parse_args()
path = Path(args.file)
data = json.loads(path.read_text(encoding="utf-8"))

fields = ["id", "title", "profile", "repo", "year", "medium", "provenance", "confidence", "description", "preview", "sourceUrl", "chapter"]
work = {field: input(f"{field}: ").strip() for field in fields}
work["featured"] = input("featured [j/N]: ").strip().lower() in {"j", "ja", "y", "yes"}
work["tags"] = [x.strip() for x in input("tags (kommaseparert): ").split(",") if x.strip()]

data["works"].append(work)
path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"La til {work['title']} i {path}")
