@echo off
setlocal
set VERSION=9.5.0
set BASE=%USERPROFILE%\.gradle\blckswan-bootstrap
set ZIP=%BASE%\gradle-%VERSION%-bin.zip
set GRADLE_HOME=%BASE%\gradle-%VERSION%
if exist "%GRADLE_HOME%\bin\gradle.bat" goto run
if not exist "%BASE%" mkdir "%BASE%"
if not exist "%ZIP%" powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-9.5.0-bin.zip' -OutFile '%ZIP%'"
powershell -NoProfile -Command "Expand-Archive -Force '%ZIP%' '%BASE%'"
:run
call "%GRADLE_HOME%\bin\gradle.bat" %*
