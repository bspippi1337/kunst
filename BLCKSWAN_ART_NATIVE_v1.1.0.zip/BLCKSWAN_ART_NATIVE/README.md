# BLCKSWAN ART — Native Android Art Exhibition

En selvstendig, offline Android-app for publisering og utstilling av BLCKSWAN-kunsten.

## Hva som er annerledes

- **Native Jetpack Compose**, ikke WebView.
- **41 kuraterte verk** lastes fra én lokal JSON-fil.
- Galleri, søk, mediumfilter, favoritter og detaljvisning.
- Native konstellasjonskart for identiske commits, blobs og motiver.
- Tidslinje fra commitkunst til BLCKSWAN OS.
- Fullskjerms **utstillingsmodus** med automatisk rotasjon.
- Offline og uten konto, server, analyseverktøy, eksterne fonter eller API-nøkler.
- Android Sharesheet og lenke til originalobjektet når kilde finnes.

## Bygg

Krever JDK 17+, Android SDK 37 og Build Tools 36.0.0.

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Release:

```bash
./gradlew assembleRelease
```

## Publiser nytt verk

Rediger:

```text
app/src/main/assets/exhibition.json
```

Hvert verk er et JSON-objekt med tittel, profil, repo, år, medium, beskrivelse, eventuell ASCII-preview og kildeadresse. Appens UI trenger ikke endres.

Et lite hjelpeverktøy følger med:

```bash
python3 tools/add_artwork.py --file app/src/main/assets/exhibition.json
```

## GitHub Actions

Workflowen `.github/workflows/android.yml` bygger en debug-APK ved push og laster den opp som artifact. Tags på formen `v*` bygger også release-APK og oppretter GitHub Release.

## Teknisk grunnlag

- Android Gradle Plugin 9.3.0
- Gradle 9.5.0
- Kotlin / Compose Compiler plugin 2.3.21
- Compose BOM 2026.06.00
- compileSdk / targetSdk 37
- minSdk 26

## Lisens

Appskallet kan gjenbrukes og tilpasses. Kunstverk, tekster og Git-objekter beholder sine respektive opphavs- og kildeforhold.


## Hovedverk: FUCK KUNST (DANS DANS)

Appen kobler Git-verket **FUCK KUNST: DANS DANS!** til Honningbarnas sang og offisielle musikkvideo. Den viser publisert kreditering: **Go Pro — Anders Tendenes**, og presiserer at dette dokumenterer medvirkning som kameraoperatør i videoen, ikke som musiker på lydsporet.

Eksterne medier strømmes ikke eller pakkes inn i APK-en. Appen åpner YouTube, Vimeo, Apple Music og dokumentasjonskildene i brukerens valgte app/nettleser.
