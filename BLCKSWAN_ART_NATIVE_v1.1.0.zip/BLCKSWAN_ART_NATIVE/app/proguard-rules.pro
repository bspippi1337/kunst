# BLCKSWAN ART uses no reflection-based app libraries.
