
@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package org.blckswan.art

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.net.Uri
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Workspaces
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BlckSwanApp() {
    val context = LocalContext.current
    val exhibition = remember { ArtRepository.load(context) }
    val preferences = remember { context.getSharedPreferences("blckswan_art", Context.MODE_PRIVATE) }
    val favourites = remember {
        mutableStateListOf<String>().apply { addAll(preferences.getStringSet("favourites", emptySet()).orEmpty()) }
    }

    var section by rememberSaveable { mutableStateOf(AppSection.GALLERY) }
    var selected by remember { mutableStateOf<Artwork?>(null) }
    var exhibitionMode by rememberSaveable { mutableStateOf(false) }

    fun toggleFavourite(id: String) {
        if (id in favourites) favourites.remove(id) else favourites.add(id)
        preferences.edit().putStringSet("favourites", favourites.toSet()).apply()
    }

    when {
        exhibitionMode -> ExhibitionMode(exhibition.works.filter { it.featured }.ifEmpty { exhibition.works }) {
            exhibitionMode = false
        }
        selected != null -> ArtworkDetail(
            artwork = selected!!,
            favourite = selected!!.id in favourites,
            onBack = { selected = null },
            onFavourite = { toggleFavourite(selected!!.id) }
        )
        else -> Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = SurfaceBlack) {
                    AppSection.entries.forEach { item ->
                        val icon = when (item) {
                            AppSection.GALLERY -> Icons.Default.GridView
                            AppSection.CONSTELLATION -> Icons.Default.Workspaces
                            AppSection.TIMELINE -> Icons.Default.Timeline
                            AppSection.MANIFEST -> Icons.Default.Info
                        }
                        NavigationBarItem(
                            selected = section == item,
                            onClick = { section = item },
                            icon = { Icon(icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Crossfade(section, modifier = Modifier.padding(padding), label = "section") { current ->
                when (current) {
                    AppSection.GALLERY -> GalleryScreen(
                        exhibition = exhibition,
                        favourites = favourites,
                        onArtwork = { selected = it },
                        onExhibition = { exhibitionMode = true }
                    )
                    AppSection.CONSTELLATION -> ConstellationScreen(exhibition.connections)
                    AppSection.TIMELINE -> TimelineScreen(exhibition.timeline)
                    AppSection.MANIFEST -> ManifestScreen(onExhibition = { exhibitionMode = true })
                }
            }
        }
    }
}

@Composable
private fun GalleryScreen(
    exhibition: Exhibition,
    favourites: List<String>,
    onArtwork: (Artwork) -> Unit,
    onExhibition: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedMedium by rememberSaveable { mutableStateOf("Alle") }
    var favouritesOnly by rememberSaveable { mutableStateOf(false) }
    val media = remember(exhibition.works) { listOf("Alle") + exhibition.works.map { it.medium }.distinct().sorted() }
    val filtered = exhibition.works.filter { work ->
        (selectedMedium == "Alle" || work.medium == selectedMedium) &&
            (!favouritesOnly || work.id in favourites) &&
            (query.isBlank() || listOf(work.title, work.profile, work.repo, work.medium, work.description)
                .joinToString(" ").contains(query, ignoreCase = true))
    }

    Column(Modifier.fillMaxSize()) {
        GalleryHeader(
            title = exhibition.title,
            subtitle = exhibition.subtitle,
            edition = exhibition.edition,
            onExhibition = onExhibition
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotBlank()) IconButton(onClick = { query = "" }) {
                    Icon(Icons.Default.Close, contentDescription = "Tøm")
                }
            },
            placeholder = { Text("Søk i verk, profiler og medier") },
            shape = RoundedCornerShape(18.dp)
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = favouritesOnly,
                onClick = { favouritesOnly = !favouritesOnly },
                label = { Text("Favoritter") },
                leadingIcon = { Icon(Icons.Default.Favorite, contentDescription = null, Modifier.size(17.dp)) }
            )
            media.forEach { medium ->
                FilterChip(
                    selected = selectedMedium == medium,
                    onClick = { selectedMedium = medium },
                    label = { Text(medium, maxLines = 1) }
                )
            }
        }
        AnimatedContent(filtered.size, label = "count") { count ->
            Text(
                "$count verk i denne visningen",
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 2.dp),
                color = Fog,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(165.dp),
            contentPadding = PaddingValues(12.dp, 10.dp, 12.dp, 30.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filtered, key = { it.id }) { artwork ->
                ArtworkCard(
                    artwork = artwork,
                    favourite = artwork.id in favourites,
                    onClick = { onArtwork(artwork) }
                )
            }
        }
    }
}

@Composable
private fun GalleryHeader(title: String, subtitle: String, edition: String, onExhibition: () -> Unit) {
    Box(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF10261A), Ink)))
            .padding(WindowInsets.statusBars.asPaddingValues())
            .padding(horizontal = 18.dp, vertical = 22.dp)
    ) {
        Column(Modifier.fillMaxWidth()) {
            Text(edition.uppercase(), color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(title, fontSize = 39.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.8).sp)
            Text(subtitle, color = Fog, fontSize = 16.sp)
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onExhibition,
                colors = ButtonDefaults.buttonColors(containerColor = SwanGreen, contentColor = Ink),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Start utstillingsmodus", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ArtworkCard(artwork: Artwork, favourite: Boolean, onClick: () -> Unit) {
    val accent = artworkAccent(artwork)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = RaisedBlack),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(accent.copy(.7f), Hairline)))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(7.dp))
                Text(artwork.medium.uppercase(), color = accent, fontFamily = FontFamily.Monospace, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.weight(1f))
                if (favourite) Icon(Icons.Default.Favorite, contentDescription = null, tint = ArchiveGold, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.height(12.dp))
            if (artwork.preview.isNotBlank()) {
                Text(
                    artwork.preview.take(220),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.sp,
                    lineHeight = 9.sp,
                    color = SwanMint,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().background(Ink, RoundedCornerShape(12.dp)).padding(9.dp)
                )
                Spacer(Modifier.height(12.dp))
            } else {
                AbstractMark(artwork, Modifier.fillMaxWidth().height(78.dp))
                Spacer(Modifier.height(8.dp))
            }
            Text(artwork.title, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(6.dp))
            Text("${artwork.profile} / ${artwork.repo}", color = Fog, fontFamily = FontFamily.Monospace, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Text(artwork.description, color = Fog, fontSize = 13.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            Row {
                Text(artwork.year, color = ArchiveGold, fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("ÅPNE →", color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun AbstractMark(artwork: Artwork, modifier: Modifier = Modifier) {
    val accent = artworkAccent(artwork)
    Canvas(modifier.clip(RoundedCornerShape(13.dp)).background(Ink)) {
        val seed = artwork.id.hashCode()
        repeat(8) { i ->
            val x = ((seed shr (i % 16)) and 0xFF) / 255f * size.width
            val y = ((seed shr ((i + 5) % 16)) and 0xFF) / 255f * size.height
            drawCircle(accent.copy(alpha = .12f + i * .04f), radius = 8f + i * 3f, center = Offset(x, y))
        }
        drawLine(accent, Offset(size.width * .08f, size.height * .78f), Offset(size.width * .92f, size.height * .22f), strokeWidth = 2f)
        drawLine(ArchiveGold.copy(.65f), Offset(size.width * .3f, 0f), Offset(size.width * .55f, size.height), strokeWidth = 1f)
    }
}

@Composable
private fun ArtworkDetail(artwork: Artwork, favourite: Boolean, onBack: () -> Unit, onFavourite: () -> Unit) {
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    val accent = artworkAccent(artwork)
    Scaffold(
        containerColor = Ink,
        topBar = {
            Row(
                Modifier.fillMaxWidth().background(Ink.copy(.96f)).padding(WindowInsets.statusBars.asPaddingValues()).padding(horizontal = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Tilbake") }
                Text(artwork.medium, modifier = Modifier.weight(1f), color = Fog, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                IconButton(onClick = onFavourite) {
                    Icon(if (favourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = "Favoritt", tint = if (favourite) ArchiveGold else Fog)
                }
                IconButton(onClick = { shareArtwork(context, artwork) }) { Icon(Icons.Default.Share, contentDescription = "Del") }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 48.dp)
        ) {
            item {
                Box(
                    Modifier.fillMaxWidth().height(260.dp)
                        .background(Brush.radialGradient(listOf(accent.copy(.42f), Ink), radius = 900f))
                ) {
                    if (artwork.preview.isBlank()) {
                        AbstractMark(artwork, Modifier.fillMaxSize().padding(24.dp))
                    } else {
                        SelectionContainer {
                            Text(
                                artwork.preview,
                                modifier = Modifier.fillMaxSize().padding(22.dp),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 12.sp,
                                color = SwanMint,
                                overflow = TextOverflow.Clip
                            )
                        }
                    }
                }
            }
            item {
                Column(Modifier.padding(20.dp)) {
                    Text(artwork.chapter.uppercase(), color = accent, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
                    Spacer(Modifier.height(7.dp))
                    Text(artwork.title, fontSize = 39.sp, lineHeight = 39.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.2).sp)
                    Spacer(Modifier.height(13.dp))
                    Text("${artwork.profile} / ${artwork.repo}", color = Fog, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    Spacer(Modifier.height(22.dp))
                    Text(artwork.description, fontSize = 18.sp, lineHeight = 27.sp)
                    Spacer(Modifier.height(24.dp))
                    MetadataRow("År", artwork.year)
                    MetadataRow("Medium", artwork.medium)
                    MetadataRow("Opphav", artwork.provenance)
                    MetadataRow("Sikkerhet", artwork.confidence)
                    if (artwork.creditNote.isNotBlank()) {
                        Spacer(Modifier.height(20.dp))
                        CreditCard(artwork.creditNote, artwork.evidenceNote, accent)
                    }
                    if (artwork.links.isNotEmpty()) {
                        Spacer(Modifier.height(22.dp))
                        Text("ÅPNE VERKET", color = ArchiveGold, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        Spacer(Modifier.height(10.dp))
                        artwork.links.forEach { link ->
                            ArtworkLinkButton(link = link, accent = accent, onOpen = { openUrl(context, link.url) })
                            Spacer(Modifier.height(9.dp))
                        }
                    } else if (artwork.sourceUrl.isNotBlank()) {
                        Spacer(Modifier.height(22.dp))
                        Button(
                            onClick = { openUrl(context, artwork.sourceUrl) },
                            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Ink),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Åpne originalobjektet")
                        }
                    }
                    Spacer(Modifier.height(26.dp))
                    HorizontalDivider(color = Hairline)
                    Spacer(Modifier.height(18.dp))
                    Text("KURATORISK LESNING", color = ArchiveGold, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(curatorialReading(artwork), color = Fog, lineHeight = 23.sp)
                }
            }
        }
    }
}


@Composable
private fun CreditCard(credit: String, evidence: String, accent: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = .10f)),
        border = BorderStroke(1.dp, accent.copy(alpha = .65f)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(17.dp)) {
            Text("DOKUMENTERT MEDVIRKNING", color = accent, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.4.sp)
            Spacer(Modifier.height(7.dp))
            Text(credit, fontSize = 20.sp, lineHeight = 24.sp, fontWeight = FontWeight.ExtraBold)
            if (evidence.isNotBlank()) {
                Spacer(Modifier.height(9.dp))
                Text(evidence, color = Fog, fontSize = 13.sp, lineHeight = 20.sp)
            }
        }
    }
}

@Composable
private fun ArtworkLinkButton(link: ArtworkLink, accent: Color, onOpen: () -> Unit) {
    val icon = when (link.kind.lowercase()) {
        "youtube", "vimeo" -> Icons.Default.SmartDisplay
        "musikk" -> Icons.Default.MusicNote
        "github" -> Icons.Default.Link
        else -> Icons.Default.OpenInNew
    }
    Button(
        onClick = onOpen,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = RaisedBlack, contentColor = accent),
        border = BorderStroke(1.dp, accent.copy(alpha = .55f)),
        shape = RoundedCornerShape(16.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 13.dp)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(link.label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(17.dp))
    }
}

@Composable
private fun MetadataRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Text(label, color = Fog, modifier = Modifier.width(90.dp), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text(value, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ConstellationScreen(connections: List<Connection>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(WindowInsets.statusBars.asPaddingValues()),
        contentPadding = PaddingValues(16.dp, 20.dp, 16.dp, 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("KONSTELLASJON", color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("Git-objekter vandrer", fontSize = 35.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.2).sp)
            Text("Identiske commits, blobs, motiver og krysslenker gjør arkivet til én organisme.", color = Fog, fontSize = 16.sp)
            Spacer(Modifier.height(18.dp))
            ConstellationCanvas(connections, Modifier.fillMaxWidth().height(330.dp))
        }
        items(connections) { connection ->
            Card(colors = CardDefaults.cardColors(containerColor = RaisedBlack), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(17.dp)) {
                    Text(connection.kind.uppercase(), color = ArchiveGold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Text(connection.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    connection.nodes.forEach { node ->
                        Text("↳ $node", color = SwanMint, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp))
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(connection.evidence, color = Fog)
                }
            }
        }
    }
}

@Composable
private fun ConstellationCanvas(connections: List<Connection>, modifier: Modifier = Modifier) {
    val nodes = remember(connections) { connections.flatMap { it.nodes }.distinct() }
    val green = SwanGreen
    val gold = ArchiveGold
    Canvas(modifier.background(SurfaceBlack, RoundedCornerShape(24.dp)).padding(10.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = minOf(size.width, size.height) * .36f
        val points = nodes.mapIndexed { index, _ ->
            val angle = (2f * PI.toFloat() * index / nodes.size) - PI.toFloat() / 2f
            Offset(center.x + cos(angle) * radius, center.y + sin(angle) * radius)
        }
        connections.forEachIndexed { ci, connection ->
            val ids = connection.nodes.mapNotNull { node -> nodes.indexOf(node).takeIf { it >= 0 } }
            ids.zipWithNext().forEach { (a, b) ->
                drawLine(if (ci % 2 == 0) green.copy(.5f) else gold.copy(.5f), points[a], points[b], strokeWidth = 2f)
            }
        }
        points.forEachIndexed { i, p ->
            drawCircle(if (i % 3 == 0) gold else green, 8f, p)
            drawCircle((if (i % 3 == 0) gold else green).copy(.16f), 22f, p)
        }
        drawIntoCanvas { canvas ->
            val paint = Paint().apply {
                color = android.graphics.Color.rgb(186, 255, 204)
                textSize = 21f
                isAntiAlias = true
                typeface = android.graphics.Typeface.MONOSPACE
            }
            nodes.forEachIndexed { i, node ->
                val label = node.takeLast(18)
                canvas.nativeCanvas.drawText(label, points[i].x + 10f, points[i].y - 10f, paint)
            }
        }
    }
}

@Composable
private fun TimelineScreen(entries: List<TimelineEntry>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(WindowInsets.statusBars.asPaddingValues()),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 40.dp)
    ) {
        item {
            Text("TIDSLINJE", color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("Fra tagg til kernel", fontSize = 36.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.2).sp)
            Text("Kunst og systembygging utvikler seg som samme språk, ikke to separate perioder.", color = Fog)
            Spacer(Modifier.height(24.dp))
        }
        items(entries) { entry -> TimelineItem(entry) }
    }
}

@Composable
private fun TimelineItem(entry: TimelineEntry) {
    Row(Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(74.dp).fillMaxHeight()) {
            Text(entry.date, color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.size(12.dp).clip(CircleShape).background(ArchiveGold))
            Box(Modifier.width(1.dp).height(92.dp).background(Hairline))
        }
        Card(
            modifier = Modifier.weight(1f).padding(bottom = 14.dp),
            colors = CardDefaults.cardColors(containerColor = RaisedBlack),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(entry.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(entry.text, color = Fog)
            }
        }
    }
}

@Composable
private fun ManifestScreen(onExhibition: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(WindowInsets.statusBars.asPaddingValues()),
        contentPadding = PaddingValues(18.dp, 22.dp, 18.dp, 48.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("MANIFEST", color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 2.sp)
            Text("GitHub er ikke lageret.", fontSize = 38.sp, lineHeight = 39.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.4).sp)
            Text("Det er veggen, trykkpressen, arkivet, scenen og tidsmaskinen.", color = Fog, fontSize = 18.sp, lineHeight = 26.sp)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onExhibition, colors = ButtonDefaults.buttonColors(containerColor = SwanGreen, contentColor = Ink), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Kjør som utstilling")
            }
        }
        item { ManifestCard("01", "Verket er objektet", "Repo, commit, blob, branch, README, filnavn og kildekode kan alle være bærere av verket. Appen forsøker ikke å flate dem ut til skjermbilder.") }
        item { ManifestCard("02", "Publisering er data", "Utstillingen leses fra assets/exhibition.json. Legg til et verk der, bygg ny APK, og hele galleriet oppdateres uten å omskrive grensesnittet.") }
        item { ManifestCard("03", "Offline betyr varig", "Ingen konto, server, API-nøkkel, WebView, sporing eller ekstern font er nødvendig. APK-en bærer utstillingen i seg selv.") }
        item { ManifestCard("04", "Originalen står åpen", "Når en kildeadresse finnes, åpner appen Git-objektet. Kuratering erstatter ikke originalen; den lager en inngang til den.") }
        item { ManifestCard("05", "Utstillingsmodus", "En mobil, et nettbrett eller en veggskjerm kan rotere de utvalgte verkene automatisk. Trykk for neste verk, hold inne for å avslutte.") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceBlack), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("PUBLISER ET NYTT VERK", color = ArchiveGold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("1. Rediger exhibition.json\n2. Legg inn tittel, medium, tekst og eventuell ASCII-preview\n3. Kjør ./gradlew assembleRelease\n4. Distribuer APK-en eller publiser via GitHub Actions", lineHeight = 24.sp)
                }
            }
        }
    }
}

@Composable
private fun ManifestCard(number: String, title: String, text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = RaisedBlack), shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.padding(18.dp)) {
            Text(number, color = SwanGreen, fontFamily = FontFamily.Monospace, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(text, color = Fog, lineHeight = 22.sp)
            }
        }
    }
}

@Composable
private fun ExhibitionMode(works: List<Artwork>, onExit: () -> Unit) {
    val activity = LocalContext.current as? Activity
    var index by rememberSaveable { mutableIntStateOf(0) }
    var paused by rememberSaveable { mutableStateOf(false) }
    val work = works[index % works.size]
    val accent = artworkAccent(work)

    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    BackHandler(onBack = onExit)
    LaunchedEffect(index, paused) {
        if (!paused) {
            delay(8500)
            index = (index + 1) % works.size
        }
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.radialGradient(listOf(accent.copy(.28f), Ink), radius = 1200f))
            .combinedClickable(
                onClick = { index = (index + 1) % works.size },
                onLongClick = onExit
            )
            .padding(WindowInsets.statusBars.asPaddingValues())
            .padding(WindowInsets.navigationBars.asPaddingValues())
    ) {
        AnimatedContent(work, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "exhibition") { art ->
            Column(Modifier.fillMaxSize().padding(26.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("BLCKSWAN ART / UTSTILLING", color = accent, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${index + 1}/${works.size}", color = Fog, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
                Box(Modifier.fillMaxWidth().weight(1f).padding(vertical = 20.dp), contentAlignment = Alignment.Center) {
                    if (art.preview.isNotBlank()) {
                        Text(
                            art.preview,
                            fontFamily = FontFamily.Monospace,
                            color = SwanMint,
                            fontSize = 13.sp,
                            lineHeight = 14.sp,
                            maxLines = 26,
                            overflow = TextOverflow.Clip
                        )
                    } else {
                        AbstractMark(art, Modifier.fillMaxWidth().height(300.dp))
                    }
                }
                Column {
                    Text(art.medium.uppercase(), color = accent, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Text(art.title, fontSize = 43.sp, lineHeight = 43.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.6).sp)
                    Spacer(Modifier.height(10.dp))
                    Text(art.description, color = Fog, fontSize = 16.sp, lineHeight = 23.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(14.dp))
                    Text("${art.profile} / ${art.repo} · ${art.year}", color = ArchiveGold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }
        Row(Modifier.align(Alignment.TopEnd).padding(top = 32.dp, end = 12.dp)) {
            TextButton(onClick = { paused = !paused }) { Text(if (paused) "FORTSETT" else "PAUSE") }
            TextButton(onClick = onExit) { Text("AVSLUTT") }
        }
    }
}

private fun artworkAccent(artwork: Artwork): Color {
    val palette = listOf(SwanGreen, ArchiveGold, SwanMint, Color(0xFF65A7FF), Color(0xFFFF7AB6))
    return palette[(artwork.id.hashCode() and Int.MAX_VALUE) % palette.size]
}

private fun curatorialReading(artwork: Artwork): String = when {
    artwork.medium.contains("Git", true) || artwork.medium.contains("Commit", true) ->
        "Her er versjonskontroll ikke bare teknisk infrastruktur. Tid, identitet og konflikt blir synlige som materiale. Verket eksisterer derfor både som tekst og som historikken rundt teksten."
    artwork.preview.isNotBlank() ->
        "Monospaceflaten er ikke en illustrasjon av verket, men en del av det. Avstand, tegnbredde og linjeskift fungerer som komposisjon på samme måte som form og negativt rom i grafikk."
    artwork.medium.contains("spill", true) || artwork.medium.contains("Interaktiv", true) ->
        "Publikum leser ikke bare dette verket. De utfører det. Reglene, ventingen og tilbakemeldingene gjør erfaringen fysisk og tidsbundet."
    artwork.medium.contains("system", true) || artwork.medium.contains("programvare", true) ->
        "I denne fasen opphører skillet mellom kunstobjekt og verktøy. Systemet kan brukes, bygges og feile, men bærer fortsatt språk, identitet og estetikk i arkitekturen."
    else ->
        "Verket bruker repoet som ramme og tittelmaskin. Det som vanligvis er metadata, blir her en del av selve lesningen."
}

private fun shareArtwork(context: Context, artwork: Artwork) {
    val body = buildString {
        appendLine(artwork.title)
        appendLine("${artwork.profile} / ${artwork.repo} · ${artwork.year}")
        appendLine()
        appendLine(artwork.description)
        if (artwork.preview.isNotBlank()) {
            appendLine()
            appendLine(artwork.preview)
        }
        if (artwork.creditNote.isNotBlank()) {
            appendLine()
            appendLine(artwork.creditNote)
        }
        if (artwork.links.isNotEmpty()) {
            appendLine()
            artwork.links.forEach { appendLine("${it.label}: ${it.url}") }
        } else if (artwork.sourceUrl.isNotBlank()) {
            appendLine()
            appendLine(artwork.sourceUrl)
        }
    }
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, artwork.title)
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(intent, "Del verk"))
}

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
