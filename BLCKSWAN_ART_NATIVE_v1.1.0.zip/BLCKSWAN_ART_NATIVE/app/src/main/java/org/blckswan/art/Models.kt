
package org.blckswan.art

data class Exhibition(
    val title: String,
    val subtitle: String,
    val edition: String,
    val works: List<Artwork>,
    val connections: List<Connection>,
    val timeline: List<TimelineEntry>
)

data class Artwork(
    val id: String,
    val title: String,
    val profile: String,
    val repo: String,
    val year: String,
    val medium: String,
    val provenance: String,
    val confidence: String,
    val description: String,
    val preview: String,
    val sourceUrl: String,
    val links: List<ArtworkLink>,
    val creditNote: String,
    val evidenceNote: String,
    val featured: Boolean,
    val chapter: String,
    val tags: List<String>
)

data class ArtworkLink(
    val label: String,
    val url: String,
    val kind: String
)

data class Connection(
    val title: String,
    val kind: String,
    val nodes: List<String>,
    val evidence: String
)

data class TimelineEntry(
    val date: String,
    val title: String,
    val text: String
)

enum class AppSection(val label: String) {
    GALLERY("Verk"),
    CONSTELLATION("Kart"),
    TIMELINE("Tid"),
    MANIFEST("Manifest")
}
