
package org.blckswan.art

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ArtRepository {
    fun load(context: Context): Exhibition {
        val raw = context.assets.open("exhibition.json").bufferedReader().use { it.readText() }
        val root = JSONObject(raw)
        return Exhibition(
            title = root.getString("title"),
            subtitle = root.getString("subtitle"),
            edition = root.getString("edition"),
            works = root.getJSONArray("works").mapObjects(::parseArtwork),
            connections = root.getJSONArray("connections").mapObjects(::parseConnection),
            timeline = root.getJSONArray("timeline").mapObjects(::parseTimeline)
        )
    }

    private fun parseArtwork(o: JSONObject) = Artwork(
        id = o.getString("id"),
        title = o.getString("title"),
        profile = o.getString("profile"),
        repo = o.getString("repo"),
        year = o.getString("year"),
        medium = o.getString("medium"),
        provenance = o.getString("provenance"),
        confidence = o.getString("confidence"),
        description = o.getString("description"),
        preview = o.optString("preview"),
        sourceUrl = o.optString("sourceUrl"),
        links = o.optJSONArray("links")?.mapObjects(::parseArtworkLink).orEmpty(),
        creditNote = o.optString("creditNote"),
        evidenceNote = o.optString("evidenceNote"),
        featured = o.optBoolean("featured"),
        chapter = o.optString("chapter"),
        tags = o.optJSONArray("tags")?.toStringList().orEmpty()
    )

    private fun parseArtworkLink(o: JSONObject) = ArtworkLink(
        label = o.getString("label"),
        url = o.getString("url"),
        kind = o.optString("kind", "Lenke")
    )

    private fun parseConnection(o: JSONObject) = Connection(
        title = o.getString("title"),
        kind = o.getString("kind"),
        nodes = o.getJSONArray("nodes").toStringList(),
        evidence = o.getString("evidence")
    )

    private fun parseTimeline(o: JSONObject) = TimelineEntry(
        date = o.getString("date"),
        title = o.getString("title"),
        text = o.getString("text")
    )

    private fun <T> JSONArray.mapObjects(block: (JSONObject) -> T): List<T> =
        List(length()) { index -> block(getJSONObject(index)) }

    private fun JSONArray.toStringList(): List<String> =
        List(length()) { index -> getString(index) }
}
