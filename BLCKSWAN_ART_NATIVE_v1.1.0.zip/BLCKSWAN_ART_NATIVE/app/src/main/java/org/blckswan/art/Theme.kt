
package org.blckswan.art

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF040706)
val SurfaceBlack = Color(0xFF0A100D)
val RaisedBlack = Color(0xFF111A16)
val SwanGreen = Color(0xFF66F59A)
val SwanMint = Color(0xFFBAFFCC)
val ArchiveGold = Color(0xFFE9C76D)
val Fog = Color(0xFFA6B6AC)
val Hairline = Color(0xFF294335)
val AlertRed = Color(0xFFFF9B9B)

private val BlckSwanColors = darkColorScheme(
    primary = SwanGreen,
    onPrimary = Ink,
    secondary = ArchiveGold,
    onSecondary = Ink,
    tertiary = SwanMint,
    background = Ink,
    onBackground = Color(0xFFF0F6F2),
    surface = SurfaceBlack,
    onSurface = Color(0xFFF0F6F2),
    surfaceVariant = RaisedBlack,
    onSurfaceVariant = Fog,
    outline = Hairline,
    error = AlertRed
)

@Composable
fun BlckSwanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BlckSwanColors, content = content)
}
