# FUCK KUNST (DANS DANS) — kilde- og krediteringsnotat

## Dokumentert medvirkning

Publiserte videokreditter for Honningbarna-videoen oppgir:

> Go Pro: Anders Tendenes

Dette dokumenterer medvirkning som GoPro-/kameraoperatør i den offisielle musikkvideoen. Det er ikke dokumentasjon på at Anders er utøvende musiker på lydsporet.

## Produksjonskontekst

Stavanger Aftenblad beskrev før opptaket at kameraer skulle festes på publikummere under Tvangsfestivalen på Figgjo. Honningbarna ønsket en konsertvideo bygget av noe ekte, med brøl, dans og bevegelse uten falske fasader.

## Kilder og medielenker

- Vimeo-original: https://vimeo.com/59665152
- YouTube-søk etter offisiell video: https://www.youtube.com/results?search_query=Honningbarna+Fuck+kunst+dans+dans+Official+Video
- Apple Music: https://music.apple.com/no/song/688667436
- Stavanger Aftenblad: https://www.aftenbladet.no/kultur/i/1y9xX/du-kan-filme-honningbarnas-nye-musikkvideo
- Publiserte videokreditter: https://videos.antville.org/archive/2013/03/05/

Appen inkluderer ikke selve lyd- eller videofilen. Den åpner lovlige eksterne avspillings- og dokumentasjonskilder.
