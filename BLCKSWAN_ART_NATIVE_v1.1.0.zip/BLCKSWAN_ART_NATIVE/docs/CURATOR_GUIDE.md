# Kuratorguide

## Publiseringsmodellen

Appen skiller mellom **utstillingsmotoren** og **kunsten**. Motoren er Compose-koden. Kunsten ligger i `exhibition.json`.

### Felter

- `id`: stabil, unik slug
- `title`: verkets visningstittel
- `profile` og `repo`: objektets plass i Git-nettverket
- `year`: kan være enkeltår eller tidsrom
- `medium`: brukes som filter
- `provenance`: originalt verk, intervensjon, remix eller systemarbeid
- `confidence`: kuratorisk sikkerhet
- `description`: kort katalogtekst
- `preview`: valgfri ASCII, terminaltekst eller kodefragment
- `sourceUrl`: valgfri lenke til originalobjektet
- `featured`: om verket skal inngå i utstillingsmodus
- `chapter`: overordnet kuratorisk kapittel

## Prinsipper

1. Ikke gjør repoantall til hovedverket.
2. Ikke fjern upstream-opphav for å gjøre historien penere.
3. Ikke publiser fødselsnummerlignende identifikatorer som dekor.
4. Bruk preview sparsomt. Store verk bør få puste.
5. La kildeobjektet være tilgjengelig når det er forsvarlig.
