# Build notes

Projectet er satt opp for Android API 37, AGP 9.3.0, Gradle 9.5.0 og Compose BOM 2026.06.00.

Den ferdige kildepakken inneholder Gradle wrapper. Ved første bygg lastes Android- og Compose-avhengigheter fra Googles og Maven Centrals repositories.
